To run and compile you must have C# Version > 6.*

=)